# include <iostream>

# include <cstring>

# include "doente.h"
# include "util.h"

using namespace std;

void amosarDoente( Doente oDoente )
{
    char meses [ ][ 12 ] = {"xaneiro", "febreiro", "marzo", "abril", "maio", "xunho", "xullo", "agosto", "setembro", "outubro", "novembro", "decembro"};      // Para visualizar os meses
    cout << "\n\tNome: " << oDoente.nome;
    cout << "\n\tDNI: " << oDoente.DNI;
    cout << "\n\tDomicilio: " << oDoente.domicilio;
    cout << "\n\tCodigo: " << oDoente.codigo;
    cout << "\n\tTipoConsulta: " << oDoente.tipoConsulta;
    cout << "\n\tData de nacemento: " << oDoente.nacemento.dia << " de " << meses [ oDoente.nacemento.mes -1 ] << " de " << oDoente.nacemento.ano << endl;
    cout << "\n------------------------------------------------------\n";
}

void listarDoentes( setDoentes &variosDoentes )  // Listar todas os doentes
{
    int i;
    if ( variosDoentes.numDoentes == 0 ) {
        cout << "\nNon existen doentes que listar.\n";
    }
    else {
        cout << "\nListando doentes...\n";
        for (i = 0; i < variosDoentes.numDoentes; i++ ) {
            cout << "\nDoente : " << i;
            amosarDoente( variosDoentes.Doentes[ i ] );
        }
    }
}
