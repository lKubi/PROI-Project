# include <cstring>

# include "arquivo.h"
# include "doente.h"

using namespace std;


void cargarArquivo (char nome [ ], setDoentes &variosDoentes) {
    ifstream fentrada;
    Doente oDoente;
    variosDoentes.numDoentes = 0;

    fentrada.open ( nome, ios::in | ios::binary );
    if ( !fentrada ) {
        cout << "Erro na apertura do arquivo.";
        exit ( -1 );
    }
    else {
        fentrada.read( (char *) &oDoente, sizeof ( Doente ) );
        while( ! fentrada.eof() ) {
            variosDoentes.Doentes [variosDoentes.numDoentes++] = oDoente;
            fentrada.read( (char *) &oDoente, sizeof ( Doente ) );
    };
    fentrada.close ( );
    }
}

