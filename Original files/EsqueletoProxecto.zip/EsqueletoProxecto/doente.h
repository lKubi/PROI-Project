#ifndef Doente_H_INCLUDED
#define Doente_H_INCLUDED

    # include "estrutura.h"

    // Declaracións das funcións necesarias específicas para xestionar doentes

    // Funcionalidades proporcionadas
    void amosarDoente ( Doente oDoente );
    void listarDoentes ( setDoentes &variosDoentes );

#endif // UTIL_H_INCLUDED
